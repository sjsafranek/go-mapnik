#!/bin/bash

# Notes:
# https://z.cowyo.com/caddying/view

echo "Setting workspace"
export GOPATH="`pwd`"

echo "Installing requirements"
if [ ! -d "`pwd`/src/github.com/mholt/caddy" ]; then
	echo "installing caddy..."
	go get github.com/mholt/caddy
fi

if [ ! -d "`pwd`/src/github.com/captncraig/cors" ]; then
	echo "installing caddy cors..."
	go get github.com/captncraig/cors
fi

