go-shlex is a simple lexer for go that supports shell-style quoting,
commenting, and escaping.
