package caddytls

// *********************************** NOTE ********************************
// Due to circular package dependencies with the storagetest sub package and
// the fact that we want to use that harness to test file storage, the tests
// for file storage are done in the storagetest package.
