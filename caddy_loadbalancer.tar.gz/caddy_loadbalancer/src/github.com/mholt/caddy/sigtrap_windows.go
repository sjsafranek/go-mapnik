package caddy

func trapSignalsPosix() {}
